var app = angular.module("Bookmark", ['firebase']);  
app.controller("Ctrl", function ($scope, $firebaseArray, $http) {
	$scope.url;  

    var firebaseURL = "https://kostbm.firebaseio.com/";

    $scope.getList = function(url) {
      console.log('getList');
    	var echoRef = new Firebase(url);
  		var query = echoRef.orderByChild("url");
  		$scope.urlArr = $firebaseArray(query);
    };

    $scope.add = function() {
      console.log('add');
      angular.element('#loading').toggleClass('hide');
      angular.element('#block').toggleClass('hide');
      $http.get('getImageAndThumb.php', {params: {url: $scope.url}}).success(function(data, status, headers, config) {
        console.log(data);
        var shorten;
        if ((data['title'].length + $scope.url.length) > 40) {
          shorten = $scope.url.substr(0, 40 - data['title'].length) + "...";
        }
        else {
          shorten = $scope.url;
        }
        $scope.urlArr.$add({
          url: $scope.url,
          shortUrl: shorten,
          title: data['title'],
          thumbUri: data['thumb_path']
        });
        angular.element('#loading').toggleClass('hide');
        angular.element('#block').toggleClass('hide');
        angular.element('#input').val("");
        $scope.toggleInput();
      }).error(function(data, status, headers, config) {
        alert('Error occur');
        angular.element('#loading').toggleClass('hide');
        angular.element('#block').toggleClass('hide');
      });

    };

    $scope.remove = function (url) {
      console.log('remove');
      $scope.urlArr.$remove(url);
    };


    $scope.FBLogin = function () {
      console.log('FBLogin');
      var ref = new Firebase(firebaseURL);
      ref.authWithOAuthPopup("facebook", function(error, authData) {
        if (error) {
          console.log("Login Failed!", error);
        }
        else {
          $scope.$apply(function() {
            $scope.$authData = authData;
          });
          console.log("Authenticated successfully with payload:", authData);

          // do something with the login info
          $scope.userName = authData.facebook.displayName;
          $scope.getList(firebaseURL + 'Customer/' + authData.uid);
        }
     });
   };

    $scope.FBLogout = function () {
      console.log('FBLogout');
      if ($scope.$authData == undefined) {
        return;
      }
      var ref = new Firebase(firebaseURL);
      ref.unauth();
      delete $scope.$authData;

      // do something after logout
      delete $scope.urlArr;
    };

    $scope.getWeather = function(city) {
      console.log('getWeather');
      //http://api.openweathermap.org/data/2.5/weather?q=seoul,uk&appid=2de143494c0b295cca9337e1e96b00e0
      $http.get('http://api.openweathermap.org/data/2.5/weather', 
        {params: {q: city, appid:'2de143494c0b295cca9337e1e96b00e0'}}).
        success(function(data, status, headers, config) {
          $scope.weatherData = data;
        }).
        error(function(data, status, headers, config) {});

    }

    $scope.toggleInput = function() {
      console.log('hide');
      angular.element('#urlForm').toggleClass('hide');
    }

    // get weather
    $scope.getWeather('seoul');
});